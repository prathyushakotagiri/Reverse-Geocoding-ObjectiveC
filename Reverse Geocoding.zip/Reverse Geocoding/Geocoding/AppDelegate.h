//
//  AppDelegate.h
//  Geocoding
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

