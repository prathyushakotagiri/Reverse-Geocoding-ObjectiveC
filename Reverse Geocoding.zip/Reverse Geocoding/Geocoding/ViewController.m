//
//  ViewController.m
//  Geocoding
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

#define theCoordinate CLLocationCoordinate2DMake(41.4858, -90.4997)

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //https://maps.google.com/maps/api/geocode/json?address=%@&sensor=false&key=AIzaSyC92v-4dawuKXA7Oh98BP5taftxyXUxuuE
    
    //Zooming the map with 1.5km radius,Set the visible region of the map(before 4kms)
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(theCoordinate,1500,1500);

    map.delegate = self;
    
    //Set center coordinate
    [map setCenterCoordinate:theCoordinate];
    
    //Set the visible region of the map.
    [map setRegion:region animated:YES];
    
    [self.view bringSubviewToFront:self.imgPin];
    [map bringSubviewToFront:self.imgPin];

   
    // Do any additional setup after loading the view, typically from a nib.
}


#pragma mark -
#pragma mark MKMapViewDelegate
- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    CLLocationCoordinate2D centre = [map centerCoordinate];
    
    //NSLog(@"MAP CENTER = %f,%f",centre.latitude,centre.longitude);
    
    location=[[CLLocation alloc]initWithLatitude:centre.latitude longitude:centre.longitude];
    
    [self reverseGeocoding];
}

#pragma mark- Reverse Geocoding
-(void)reverseGeocoding
{
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    
    [geocoder reverseGeocodeLocation:location completionHandler:
     ^(NSArray *placemarks, NSError *error)
     {
         if([placemarks count]>0)
         {
             //Check whether user selects the current location,then display locality,city in textfields
             placemark = [placemarks objectAtIndex:0];
             // NSLog(@"%@",placemark);
             
             NSLog(@"\n\nUnit:%@",placemark.subThoroughfare);//unit
             NSLog(@"Street:%@",placemark.thoroughfare);//street
             NSLog(@"Suburb:%@",placemark.subLocality);//suburb
             NSLog(@"City:%@",placemark.locality);//city
             NSLog(@"PostalCode:%@",placemark.postalCode);//postal code
            
             // NSLog(@"%@",placemark.subAdministrativeArea);
             // NSLog(@"%@",placemark.administrativeArea);
         }
         else
         {
             UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Could not find address" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
             [alert show];
         }
         
     }];
    
    [self performSelector:@selector(reverseGeocoding) withObject:location afterDelay:5.0];
}


#pragma mark - Reverse Geocoding
- (IBAction)reverseGeocoding:(id)sender {
    
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
       
    [geocoder reverseGeocodeLocation:location completionHandler:
     ^(NSArray *placemarks, NSError *error)
     {
         if([placemarks count]>0)
         {
             //Check whether user selects the current location,then display locality,city in textfields
             placemark = [placemarks objectAtIndex:0];
             
             NSLog(@"%@",placemark);
            
             NSLog(@"\nCity:%@",placemark.locality);//city
             NSLog(@"\nSuburb:%@",placemark.subLocality);//suburb
             NSLog(@"\nStreet:%@",placemark.thoroughfare);//street
             NSLog(@"\nUnit:%@",placemark.subThoroughfare);//unit
             NSLog(@"\nPostalCode:%@",placemark.postalCode);//postal code
             
             // NSLog(@"%@",placemark.subAdministrativeArea);
             // NSLog(@"%@",placemark.administrativeArea);
         }
         else
         {
             UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Could not find address" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
             [alert show];
         }
         
     }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
