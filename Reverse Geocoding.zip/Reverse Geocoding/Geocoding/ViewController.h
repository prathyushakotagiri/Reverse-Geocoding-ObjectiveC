//
//  ViewController.h
//  Geocoding
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<MKMapViewDelegate>
{
    CLPlacemark *placemark;
    CLLocation *location;
    
    IBOutlet MKMapView *map;
}

@property (weak, nonatomic) IBOutlet UIImageView *imgPin;

@end

