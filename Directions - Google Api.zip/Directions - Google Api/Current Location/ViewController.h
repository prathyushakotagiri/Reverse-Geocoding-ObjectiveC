//
//  ViewController.h
//  Current Location
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

#define kBaseUrl @"http://maps.googleapis.com/maps/api/directions/json?"

#define kGoogleApiKey @"AIzaSyC92v-4dawuKXA7Oh98BP5taftxyXUxuuE"
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)

@interface ViewController : UIViewController<CLLocationManagerDelegate,UITextFieldDelegate,MKMapViewDelegate>
{
    int value;

    CLLocationManager *locationManager;
    
    CLLocation *sourceLocation;
    CLLocation *destinationLocation;
    
    MKPlacemark *sourcePlacemark;
    MKPlacemark *destinationPlacemark;
    
    MKPointAnnotation *sourceAnnotation;
    MKPointAnnotation *destAnnotation;
    
    MKRoute *previousRoute;
    
    MKCircle *_5kmCircle;
    
}
@property (weak, nonatomic) IBOutlet UIView *bckgndView;

@property (weak, nonatomic) IBOutlet UILabel *lblDistance;
@property (weak, nonatomic) IBOutlet UILabel *lblDuration;

@property (weak, nonatomic) IBOutlet UITextField *txtSource;
@property (weak, nonatomic) IBOutlet UITextField *txtDestination;

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

- (IBAction)showDirections:(id)sender;

@end

